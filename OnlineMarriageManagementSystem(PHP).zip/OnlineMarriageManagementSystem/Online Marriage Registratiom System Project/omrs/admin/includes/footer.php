<div class="am-footer">
        <span style="color: blue">Copyright &copy;. Online Marriage Registration System</span>
      
      </div><!-- am-footer -->