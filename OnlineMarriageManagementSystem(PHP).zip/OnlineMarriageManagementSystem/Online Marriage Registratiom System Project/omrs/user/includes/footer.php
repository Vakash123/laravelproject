<div class="am-footer">
        <span style="color: blue">Online Marriage Registration System @ 2020.</span>
        
      </div><!-- am-footer -->