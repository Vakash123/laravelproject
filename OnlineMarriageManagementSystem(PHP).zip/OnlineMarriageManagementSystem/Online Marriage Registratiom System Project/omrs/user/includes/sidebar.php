   <div class="am-sideleft">
      <ul class="nav am-sideleft-tab">
        <li style="width:300px">
          <a href="#mainMenu" class="nav-link active"><i class="icon ion-ios-home-outline tx-24"></i></a>
        </li>
    
      </ul>

      <div class="tab-content">
        <div id="mainMenu" class="tab-pane active">
          <ul class="nav am-sideleft-menu">
            <li class="nav-item">
              <a href="dashboard.php" class="nav-link">
                <i class="icon ion-ios-home-outline"></i>
                <span>Dashboard</span>
              </a>
            </li><!-- nav-item -->
            <li class="nav-item">
              <a href="marriage-reg-form.php" class="nav-link">
                <i class="icon ion-ios-gear-outline"></i>
                <span>Registration Form</span>
              </a>
              
            </li><!-- nav-item -->
        <li class="nav-item">
              <a href="status-marriage-application.php" class="nav-link">
                <i class="icon ion-ios-folder-outline"></i>
                <span>View Marriage Application</span>
              </a>
             
            </li>
         
            <li class="nav-item">
              <a href="search.php" class="nav-link">
                <i class="icon ion-search"></i>
                <span>Search</span>
              </a>
            </li><!-- nav-item -->
          </ul>
        </div><!-- #mainMenu -->
 

      </div><!-- tab-content -->
    </div><!-- am-sideleft -->